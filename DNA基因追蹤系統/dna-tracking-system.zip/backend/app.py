from flask import Flask, request, jsonify
from difflib import SequenceMatcher
import requests

app = Flask(__name__)

data = [
    {"id": 1, "seq": "AGCTTAGCTA", "location": "Taipei", "lat": 25.033, "lon": 121.565, "timestamp": "2025-01-01"},
    {"id": 2, "seq": "AGCTTAGCTG", "location": "Kaohsiung", "lat": 22.627, "lon": 120.301, "timestamp": "2025-01-05"},
    {"id": 3, "seq": "AGCTTGGCTA", "location": "Taichung", "lat": 24.147, "lon": 120.673, "timestamp": "2025-01-10"}
]

@app.route("/api/dna/search", methods=["POST"])
def search_dna():
    seq = request.json.get("sequence", "")
    result = [{"id": d["id"], "similarity": SequenceMatcher(None, seq, d["seq"]).ratio()} for d in data]
    result.sort(key=lambda x: x["similarity"], reverse=True)
    return jsonify(result)

@app.route("/api/geocode")
def geocode():
    place = request.args.get("place")
    url = f"https://nominatim.openstreetmap.org/search"
    params = {"q": place, "format": "json"}
    res = requests.get(url, params=params, headers={"User-Agent": "DNA-Tracker"})
    if res.ok:
        js = res.json()
        if js:
            return jsonify({"lat": js[0]["lat"], "lon": js[0]["lon"]})
    return jsonify({"error": "Not found"}), 404

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")
